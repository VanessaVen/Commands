COMMANDS_CONFIG = {
    'window_size': 3,
    'log_type': 'log',
    'deletion_threshold': 2,
    "log_extension": ".txt"
}