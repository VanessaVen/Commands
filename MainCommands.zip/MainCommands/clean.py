import click
import os
import config
import logging
import sys

if config.COMMANDS_CONFIG['log_type'] == "log":
    log_path = '/Main/myapp.log'
else:
    log_path = '/Main/myapp.csv'

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO ,
format='%(asctime)s %(levelname)s %(message)s',
      filename=log_path,
      filemode='w')


@click.command()
@click.argument('path')
def clean(path):
    '''
    This command needs to keep a specific window (number of files) in the log path. 
    If they are higher, a number (deletion_threshold ) of oldest logs will be deleted.

    PATH is the directory path to clean , delete old logs if needed.

    '''
    try:
        if not os.path.exists(path):
            logging.error("Path does not exist")
            return    
        
        if not os.listdir(path):
            logging.error("Directory is empty.there is no log files to clean")
            return  
    except OSError as err:
         logging.error("OS error: {0}".format(err))
    except:
        logging.error("Unexpected error:", sys.exc_info()[0])
        raise
    
    number_of_files_to_keep = config.COMMANDS_CONFIG['window_size']
    logging.info("Number of file to keep: {0}".format(number_of_files_to_keep))
    
    deletion_threshold = config.COMMANDS_CONFIG["deletion_threshold"]
    logging.info("Number of file to delete: {0}".format(deletion_threshold))

    extension = config.COMMANDS_CONFIG["log_extension"]
    logging.info("Log extension type is: {0}".format(extension))

    filelist = []
    try:
        for root, dirs, files in os.walk(path):
            for file in files:
                if file.endswith(extension):
                    filelist.append(os.path.join(root, file))

        #Check that we have files to sort.if there are no files print to log and exit
        current_number_of_files = len(filelist) 
        if current_number_of_files == 0:
            logging.error("Directory does not have any log files to clean(with extension type {0})".format(extension))
            return  

        # sort files list according creation time 
        sortedlist = sorted(filelist, key=os.path.getmtime)[:-number_of_files_to_keep]
        filesToDelete = sortedlist[0:deletion_threshold]
        
        if len(filesToDelete) == 0:
            logging.info("No need to delete files.Current number of files: {0}".format(current_number_of_files))
            return
            
        logging.info("Total files to delete: {0}  deletion threshold: {1} ".format(len(sortedlist),deletion_threshold))
        
        for file in filesToDelete:
            logging.info("Removing file :[{0}]".format(file))
            os.remove(file)

    except OSError as err:
         logging.error("OS error: {0}".format(err))
    except:
        logging.error("Unexpected error:", sys.exc_info()[0])
        raise
    
   
        

if __name__ == "__main__":
    clean()