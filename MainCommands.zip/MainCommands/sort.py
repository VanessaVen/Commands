import click
import os
import shutil
import csv
import config
import sys
import logging

if config.COMMANDS_CONFIG['log_type'] == "log":
    log_path = '/Main/myapp.log'
else:
    log_path = '/Main/myapp.csv'

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO ,
format='%(asctime)s %(levelname)s %(message)s',
      filename=log_path,
      filemode='w')

@click.command()
@click.argument('path')
@click.option('--hash',default="C:/Main/summary.csv",help="The path for file that  save all information about the saved files")
def sort(path,hash):
    '''
    This command will take a specific directory and sort its contents based on file type. 
    For example, if we have a folder that has files of types .csv, .mat, .dxl. 
    Running the command will result into 3 subfolders within the parent one, 
    each has the name of files type and collects all of the files of this specific type.

    PATH is the directory path to sort its content.
    '''
    try:
        if not os.path.exists(path):
            logging.error("Path does not exist")
            return  
        
        if not os.listdir(path):
            logging.error("Directory is empty")
            return  

        dict = {}
        dictFiles = {}
   
        for root, dirs, files in os.walk(path):
            for file in files:
                dictFiles[os.path.abspath(os.path.join(root, file))] = file


         #Check that we have files to sort and not just empty folders
        if len(files) == 0:
            logging.error("Directory does not have files to sort")
            return          
    except OSError as err:
         logging.error("OS error: {0}".format(err))
    except:
        logging.error("Unexpected error:", sys.exc_info()[0])
        raise

    try:  
        # This will go through each and every file
        for file_ in dictFiles.keys():
            name, ext = os.path.splitext(dictFiles[file_])

            # This is going to store the extension type
            ext = ext[1:]

            # This forces the next iteration,
            # if it is the directory
            if ext == '':
                continue

            destination_file = path + '/' + ext + '/' + dictFiles[file_]    
         
            # This will move the file to the directory
            # where the name 'ext' already exists
            if os.path.exists(path + '/' + ext):
                if not os.path.isfile(destination_file):
                    shutil.move( file_,destination_file)
                    logging.info("Move file: {0} into sub folder:{1}".format(dictFiles[file_],ext))
                    if ext in dict: dict[ext] += 1

            # This will create a new directory,
            # if the directory does not already exist
            else: 
                os.makedirs(path + '/' + ext)
                logging.info("Create new sub folder for extension: {0}".format(ext))
                dict[ext] = 1
                shutil.move( file_, destination_file)
                logging.info("Move file: {0} into sub folder:{1}".format(dictFiles[file_],ext))
               
    except OSError as e:   
        logging.error('Sort directory Failed: [{0}]'.format(e))
    except:
        logging.error("Unexpected error:", sys.exc_info()[0])
        raise  
    
    try:
        w = csv.writer(open(hash, "w"))
        for key, val in dict.items():
            w.writerow([key, val])
    except IOError as e:
        logging.error("I/O error({0}): {1}".format(e.errno, e.strerror))
    except:
        logging.error("Unexpected error:", sys.exc_info()[0])
        raise  
    

if __name__ == "__main__":
    sort()